import AsyncStorage from '@react-native-async-storage/async-storage';

const ACCESS_TOKEN_KEY = 'token';
const USER_ROLE_KEY = 'role';
const USER_NAME_KEY = 'username';
const USER_LINE_KEY = '@user_line';

export async function saveAccessToken(token: string) {
  if (token) {
    await AsyncStorage.setItem(ACCESS_TOKEN_KEY, token);
  } else {
    await AsyncStorage.removeItem(ACCESS_TOKEN_KEY);
  }
}

export const getAuthToken = () => AsyncStorage.getItem(ACCESS_TOKEN_KEY);
export const getAccessToken = getAuthToken; // Geriye dönük uyumluluk için

export async function clearAccessToken() {
  await AsyncStorage.removeItem(ACCESS_TOKEN_KEY);
}

export async function saveUserRole(role: string) {
  if (role) {
    await AsyncStorage.setItem(USER_ROLE_KEY, role);
  } else {
    await AsyncStorage.removeItem(USER_ROLE_KEY);
  }
}

export async function getUserRole() {
  return AsyncStorage.getItem(USER_ROLE_KEY);
}

export async function clearUserRole() {
  await AsyncStorage.removeItem(USER_ROLE_KEY);
}

export async function saveUserName(name: string) {
  if (name) {
    await AsyncStorage.setItem(USER_NAME_KEY, name);
  } else {
    await AsyncStorage.removeItem(USER_NAME_KEY);
  }
}

export async function getUserName() {
  return AsyncStorage.getItem(USER_NAME_KEY);
}

export async function clearUserName() {
  await AsyncStorage.removeItem(USER_NAME_KEY);
}

export async function saveUserLine(line: string) {
  if (line) {
    await AsyncStorage.setItem(USER_LINE_KEY, line);
  } else {
    await AsyncStorage.removeItem(USER_LINE_KEY);
  }
}

export async function getUserLine() {
  return AsyncStorage.getItem(USER_LINE_KEY);
}

export async function clearUserLine() {
  await AsyncStorage.removeItem(USER_LINE_KEY);
}

/**
 * Kullanıcıya ait tüm verileri temizler (çıkış yapma işlemi için).
 */
export async function clearAuthData() {
  await AsyncStorage.removeItem(ACCESS_TOKEN_KEY);
  await AsyncStorage.removeItem(USER_ROLE_KEY);
  await AsyncStorage.removeItem(USER_NAME_KEY);
  await AsyncStorage.removeItem(USER_LINE_KEY);
}

export const removeAuthToken = clearAuthData; // api.ts ile uyumluluk için