// ===== 1. DÜZELTILMIŞ API.TS =====
import axios from 'axios';
import { router } from 'expo-router';
import * as SecureStore from 'expo-secure-store'; 

const TOKEN_KEY = 'accessToken'; 

const api = axios.create({
  baseURL: 'https://api2.sersim.com.tr/api', // api2'ye geri döndürüldü
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Test için farklı URL'leri dene
const testUrls = [
  'https://api.sersim.com.tr/api', // Çalışan URL'i önce dene
  'https://api2.sersim.com.tr/api',
  'https://api2.sersim.com.tr',
  'https://api.sersim.com.tr'
];

api.interceptors.request.use(
  async (config) => {
    const token = await SecureStore.getItemAsync(TOKEN_KEY);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    // FormData için Content-Type'ı kaldır, axios otomatik ayarlasın
    if (config.data instanceof FormData) {
      delete config.headers['Content-Type'];
    }
    
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => {
    console.log(`API Success: ${response.config.method?.toUpperCase()} ${response.config.url}`);
    return response;
  },
  async (error) => {
    if (error.response) {
      console.error(`API Error: ${error.response.status} - ${error.config?.method?.toUpperCase()} ${error.config?.url}`);
      console.error('Response data:', error.response.data);

      if (error.response.status === 401) {
        console.log('Unauthorized - redirecting to login');
        await SecureStore.deleteItemAsync(TOKEN_KEY);
        
        setTimeout(() => {
          try {
            router.replace('/(auth)/sign-in');
          } catch (routerError) {
            console.warn('Router redirect hatası:', routerError);
          }
        }, 100);
      }
    } else if (error.request) {
      console.error(`Network Error: ${error.config?.method?.toUpperCase()} ${error.config?.url}`);
    } else {
      console.error('Request Setup Error:', error.message);
    }

    return Promise.reject(error);
  }
);

export const testApiConnection = async () => {
  try {
    console.log('API bağlantısı test ediliyor...');
    const response = await api.get('/Users', { timeout: 10000 });
    console.log('API bağlantısı başarılı:', response.status);
    return true;
  } catch (error) {
    console.error('API bağlantı testi başarısız:', error);
    return false;
  }
};

export const testFormsEndpoint = async () => {
  try {
    console.log('Forms endpoint test ediliyor...');
    console.log('Test URL:', api.defaults.baseURL + '/Forms');
    const response = await api.get('/Forms', { timeout: 10000 });
    console.log('Forms endpoint başarılı:', response.status);
    return true;
  } catch (error: any) {
    console.error('Forms endpoint testi başarısız:', error);
    console.error('Error details:', error.response?.status, error.response?.data);
    return false;
  }
};

// Farklı URL'leri test et
export const testDifferentUrls = async () => {
  for (const url of testUrls) {
    try {
      console.log(`Testing URL: ${url}/Forms`);
      const testApi = axios.create({
        baseURL: url,
        timeout: 10000,
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      const response = await testApi.get('/Forms');
      console.log(`✅ SUCCESS: ${url}/Forms - Status: ${response.status}`);
      return url;
    } catch (error: any) {
      console.log(`❌ FAILED: ${url}/Forms - ${error.response?.status || 'Network Error'}`);
    }
  }
  return null;
};

// Default export for the api instance
export default api;